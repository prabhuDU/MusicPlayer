import os
import pickle
import tkinter as tk
from tkinter import filedialog
import yagmail
from pygame import mixer
from PIL import Image, ImageTk
from tkinter import *
import time


class Player(tk.Frame):
    def __init__(self, master=None):
        super().__init__(master)
        self.master = master
        self.pack()
        mixer.init()

        if os.path.exists('songs.pickle'):
            with open('songs.pickle', 'rb') as f:
                self.playlist = pickle.load(f)
        else:
            self.playlist = []

        self.current = 0
        self.paused = True
        self.played = False
        self.email = ""
        self.feedback = ""
        # mute start
        self.muted = False
        # mute end

        # Create Status Bar
        self.status_bar = Label(master=root, text='', bd=1, relief=GROOVE, anchor=E, bg="blue", fg="yellow")
        self.status_bar.pack(fill=X, side=BOTTOM, ipady=2)

        # feedback in menu
        menu = Menu(self.master)
        self.master.config(menu=menu)

        feedback = Menu(menu)
        menu.add_cascade(label="FEEDBACK", menu=feedback)
        feedback.config(bg="#000", fg="#fff")
        feedback.add_command(label="GIVE FEEDBACK", command=self.provide_feedback)

        self.create_frames()
        self.track_widgets()
        self.control_widgets(master)
        self.tracklist_widgets()

        self.master.bind('<Left>', self.prev_song)
        self.master.bind('<space>', self.play_pause_song)
        self.master.bind('<Right>', self.next_song)

    def provide_feedback(self):

        new_window = Toplevel(master=root)
        new_window.title("Feedback Form")

        # sets the geometry of Toplevel
        new_window.geometry("700x500")

        self.bg = PhotoImage(file="feedbackimg.png")
        Label(new_window, image=self.bg).place(x=0, y=0)

        Label(new_window, text='ENTER EMAIL', bg="#191c22",fg="white").place(x=150, y=200)
        Label(new_window, text='ENTER FEEDBACK',  bg="#191c22",fg="white").place(x=150, y=250)

        self.email = Entry(new_window, bg='white')
        self.email.pack()
        self.email.place(x=300, y=200)

        self.feedback = Text(new_window, height=8, width=25, bg='white')
        self.feedback.place(x=300, y=250)

        btn = Button(new_window, text='SEND FEEDBACK',  bg="#191c22",fg="white")
        btn.bind('<Button-1>', self.send_feedback)
        btn.place(x=300, y=400)

    def send_feedback(self, event):
        app_password = 'kacswcxafgykaxyo'  # a token for gmail
        to = 'anand.mca20.du@gmail.com'

        subject = 'Feedback'
        content = [self.feedback.get("1.0", "end-1c")]

        with yagmail.SMTP(self.email.get(), app_password) as yag:
            yag.send(to, subject, content)
            print('Sent email successfully')

    def create_frames(self):
        self.track = tk.LabelFrame(self, text='Song Track',
                                   font=("times new roman", 15, "bold"),
                                   bg="black", fg="white", bd=1, relief=tk.GROOVE)
        self.track.config(width=310, height=200)
        self.track.grid(row=0, column=0, padx=0)

        self.tracklist = tk.LabelFrame(self, text=f'PlayList - {str(len(self.playlist))}',
                                       font=("times new roman", 15, "bold"),
                                       bg="black", fg="white", bd=1, relief=tk.GROOVE)
        self.tracklist.config(width=350, height=400)
        self.tracklist.grid(row=0, column=1, rowspan=3, pady=0, padx=3)

        self.controls = tk.LabelFrame(self,
                                      font=("times new roman", 15, "bold"),
                                      bg="black", fg="white", bd=1, relief=tk.GROOVE)
        self.controls.config(width=410, height=80)
        self.controls.grid(row=2, column=0, pady=1, padx=0)

    def track_widgets(self):
        self.canvas = tk.Label(self.track, image=img, bg="#000")
        self.canvas.configure(width=400, height=240)
        self.canvas.grid(row=0, column=0)

        self.songtrack = tk.Label(self.track, font=("Yellow Tail", 16),
                                  bg="#000", fg="#644dff")
        self.songtrack['text'] = 'Music++ MP3 Player'
        self.songtrack.config(width=30, height=1)
        self.songtrack.grid(row=1, column=0, padx=0)

    def control_widgets(self, master):
        self.loadSongs = tk.Button(self.controls, bg='black', fg='#644dff', font=10)
        self.loadSongs['text'] = 'Load Songs'
        self.loadSongs['command'] = self.retrieve_songs
        self.loadSongs.grid(row=0, column=0, padx=0)

        self.loadSongs = tk.Button(self.controls, bg='black', fg='#644dff', font=10, text="EXIT", command=master.destroy)

        self.loadSongs.grid(row=1, column=2, padx=0)
            
        self.prev = tk.Button(self.controls, image=prev, bg="#000000", borderwidth=0)
        self.prev['command'] = self.prev_song
        self.prev.grid(row=0, column=1)

        self.pause = tk.Button(self.controls, image=pause, bg="#000000", borderwidth=0)
        self.pause['command'] = self.pause_song
        self.pause.grid(row=0, column=2)

        self.next = tk.Button(self.controls, image=next_, bg="#000000", borderwidth=0)
        self.next['command'] = self.next_song
        self.next.grid(row=0, column=3)

        # mute button start
        self.mute = tk.Button(self.controls, image=mute, bg="#000000",borderwidth=0)
        self.mute['command'] = self.mute_song
        self.mute.grid(row=0, column=4, padx=10)
        # mute button end

        self.volume = tk.DoubleVar(self)
        self.slider = tk.Scale(self.controls, from_=0, to=10, orient=tk.HORIZONTAL, tickinterval=5, fg="#644dff",bg="#000")

        self.slider['variable'] = self.volume
        self.slider.set(5)
        mixer.music.set_volume(0.8)
        self.slider['command'] = self.change_volume
        self.mainlabel = tk.Label(self.controls, text="Volume", fg="#644dff",bg="#644dff")
        self.slider.grid(row=0, column=5, padx=5)

    def tracklist_widgets(self):
        self.scrollbar = tk.Scrollbar(self.tracklist, orient=tk.VERTICAL)
        self.scrollbar.grid(row=0, column=1, rowspan=5, sticky='ns')

        self.list = tk.Listbox(self.tracklist, selectmode=tk.SINGLE,
                               yscrollcommand=self.scrollbar.set, selectbackground='#555', bg="#000", fg="#fff")
        self.enumerate_songs()
        self.list.config(height=22)
        self.list.bind('<Double-1>', self.play_song)

        self.scrollbar.config(command=self.list.yview)
        self.list.grid(row=0, column=0, rowspan=5)

    def retrieve_songs(self):
        self.songlist = []
        directory = filedialog.askdirectory()
        for root_, dirs, files in os.walk(directory):
            for file in files:
                if os.path.splitext(file)[1] == '.mp3':  # checking if the file is in .mp3 format
                    path = (root_ + '/' + file).replace('\\', '/')
                    self.songlist.append(path)

        with open('songs.pickle', 'wb') as f:
            pickle.dump(self.songlist, f)
        self.playlist = self.songlist
        self.tracklist['text'] = f'PlayList - {str(len(self.playlist))}'
        self.list.delete(0, tk.END)
        self.enumerate_songs()

    def enumerate_songs(self):
        for index, song in enumerate(self.playlist):
            self.list.insert(index, os.path.basename(song))

    def play_pause_song(self, event):
        if self.paused:
            self.play_song()
        else:
            self.pause_song()

    def play_time(self):
        self.current_time = mixer.music.get_pos() / 1000
        self.converted_current_time = time.strftime('%H:%M:%S', time.gmtime(self.current_time))
        self.status_bar.config(text=self.converted_current_time)

        # update time
        self.status_bar.after(1000, self.play_time)

    def play_song(self, event=None):
        if event is not None:
            self.current = self.list.curselection()[0]
            for i in range(len(self.playlist)):
                self.list.itemconfigure(i, bg="white")

        print(self.playlist[self.current])
        mixer.music.load(self.playlist[self.current])
        self.songtrack['anchor'] = 'w'
        self.songtrack['text'] = os.path.basename(self.playlist[self.current])

        self.pause['image'] = play
        self.paused = False
        self.played = True
        self.list.activate(self.current)
        self.list.itemconfigure(self.current, bg='sky blue')
        mixer.music.play()
        self.play_time()

        self.img1 = ImageTk.PhotoImage(file='music1.jpeg')
        self.img2 = ImageTk.PhotoImage(file='music2.jpeg')
        self.img3 = ImageTk.PhotoImage(file='music3.jpeg')
        self.img4 = ImageTk.PhotoImage(file='music4.jpeg')

        self.canvas1 = tk.Label(self.track, text="",bg="black")
        self.canvas1.place(x=0, y=5)

        self.animation()

    def pause_song(self):
        if not self.paused:
            self.paused = True
            mixer.music.pause()
            self.pause['image'] = pause
            self.stop_animation()
        else:
            if self.played == False:
                self.play_song()
                self.animation()
            # self.stop_animation()
            self.paused = False
            mixer.music.unpause()
            self.pause['image'] = play
            self.animation()
            # self.stop_animation()

        self.stop_animation()

    anim = None

    def stop_animation(self):
        global anim
        self.canvas1.after_cancel(anim)

    def prev_song(self, event=None):
        self.master.focus_set()
        if self.current > 0:
            self.current -= 1
        else:
            self.current = 0
        self.list.itemconfigure(self.current + 1, bg='white')
        self.play_song()

    def next_song(self, event=None):
        self.master.focus_set()
        if self.current < len(self.playlist) - 1:
            self.current += 1
        else:
            self.current = 0
        self.list.itemconfigure(self.current - 1, bg='white')
        self.play_song()

    # mute function start
    def mute_song(self):
        if self.muted: #if its muted the we'll unmute it.
            self.v = self.volume.get()
            mixer.music.set_volume(self.v / 10)
            self.muted = False
        else:# if unmute we'll mute the music.
            mixer.music.set_volume(0)
            self.muted = True
    # mute function end

    def change_volume(self, event=None):
        self.v = self.volume.get()
        mixer.music.set_volume(self.v / 10)

    def animation(self):
        global anim
        self.img1 = self.img2
        self.img2 = self.img3
        self.img3 = self.img4
        self.img4 = self.img1

        self.canvas1.config(image=self.img1)
        anim = self.canvas1.after(2000, self.animation)


# ----------------------------- Main -------------------------------------------

if __name__ == '__main__':
    root = tk.Tk()
    root.geometry('1000x1000')
    root.configure(background='black')
    root.title('Music++')
    root.iconbitmap("iconn.ico")

    
    img = PhotoImage(file='music.png')
    next_ = PhotoImage(file='next_2.png')
    prev = PhotoImage(file='previous_2.png')
    play = PhotoImage(file='play_2.png')
    pause = PhotoImage(file='pause_2.png')
    mute = PhotoImage(file='mute_2.png')

    app = Player(master=root)
    app.mainloop()
