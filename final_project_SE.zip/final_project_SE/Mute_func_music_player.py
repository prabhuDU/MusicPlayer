#mute button for the music player
muted = False
def mute_song():
    global muted
    if muted: #if its muted the we'll unmute it.
        mixer.music.set_volume(self.v / 10)
        volumeButton.configure(image = volumePhoto)
        scale.set(self.v/10)
        muted = False
    else:# if unmute we'll mute the music.
        mixer.music.set_volume(0)
        volumeButton.configure(image = mutePhoto)
        scale.set(0)
        muted = True
        
    
# add the buttons in the driver code
mutePhoto = PhotoImage(file = 'mute.png')
volumePhoto = PhotoImage(file = 'volume.png')

# and add these to the control_widget function 
volumeButton = Button(bottomframe, image = volumePhoto, command = mute_song)
volumeButton.grid(row=0, column =1)

'''please make the changes accordingly if reqired, download and add the suitable
images for the mute and volume(unmute) buttons'''
